// src/utils/categories.js

export const categories = {
    1: 'Food',
    2: 'Transportation',
    3: 'Utilities',
    4: 'Entertainment',
    5: 'Health',
    6: 'Other',
    // Add more categories as needed
  };
  